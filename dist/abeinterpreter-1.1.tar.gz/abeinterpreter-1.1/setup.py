from distutils.core import setup

setup(name='AbeInterpreter',
      version='1.0',
      description='Interpreter the Abraham esolang',
      author='Byron Himes',
      author_email='TheByronHimes@gmail.com',
      url='https://www.byronhimes.com/abraham',
     )
