# Abraham
Novelty language interpreter

Here are the commands:
Move right x cells: Overhead, the geese flew x miles east. 
Move left x cells: Overhead, the geese flew x miles west. 
Add to cell value: He sold x sheep.
Subtract from cell value: They paid for their x mistakes.
Print cell value: And Abraham spoke!
Take input and store in cell: He listened when his wife spoke.
While loop: He ran into the mountains (but only when ___). This is what happened there:
Signal loop end: Alas, I digress.
Loop conditions act on current cell value.
	If greater than cell val: they had more than x fish
	If less than cell val: they had less than x fish
	If equal to cell val: they had x fish OR the stone said "x" (for a string)
Copy: One day he stole his neighbor's goods.
Paste: He repented and returned the property.

Sample program to multiply a number by 2:
Preparing for the storm, he inscribed "'Enter the number you wish to multiply by 2: '" into the stone.
And Abraham spoke!
He listened when his wife spoke. 
He ran up into the mountains (but only when they had more than 0 fish). This is what happened there: 
They paid for their 1 mistakes. 
Overhead, the geese flew 1 miles east. 
He sold 2 sheep. 
Overhead, the geese flew 1 miles west. 
Alas, I digress. 
Overhead, the geese flew 1 miles east. 
And Abraham spoke!